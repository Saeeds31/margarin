<template>
  <div class="mainContentAdmin" id="weblogCategories">
    <b-overlay :show="status" no-wrap fixed z-index="9999">
      <template v-slot:overlay>
        <div class="d-flex align-items-center">
          <b-spinner small type="grow" variant="dark" class="mx-1"></b-spinner>
          <b-spinner type="grow" variant="dark" class="mx-1"></b-spinner>
          <b-spinner small type="grow" variant="dark" class="mx-1"></b-spinner>
        </div>
      </template>
    </b-overlay>
    <div class="filters">
      <b-button variant="primary" @click="showModal = true">افزودن </b-button>
    </div>
    <div v-if="items" class="mainTable">
       <s-table
                    v-model="items"
                    @showEditModal="showEditModal"
                    @deleteItem="deleteItem"
                    :headers="headers"
                  />
    </div>
    <b-modal
      id="categoryModal"
      hide-footer
      ref="categoryModal"
      no-close-on-backdrop
      v-model="showModal"
      @close="resetModal()"
      :title="mode == 'create' ? 'افزودن ' + title : ' ویرایش ' + title"
    >
      <s-inputs
        :disabled="disabled"
        @submit="submit"
        :mode="mode"
        :bigData="bigData"
        :headers="headers"
      />
    </b-modal>
  </div>
</template>
<script>
import SInputs from "@/components/admin/shared/sInputs.vue";
import STable from "@/components/admin/shared/sTable.vue";
import adminMixin from "@/libraries/adminController.js"
import { BModal, BButton,BOverlay,BSpinner } from "bootstrap-vue";
export default {
mixins:[adminMixin],
  components: { SInputs, BModal, BButton, STable,BOverlay,BSpinner },
  data() {
    return {
      headers: [
        {
          style: "col-12",
          show_in_table: true,
          placeholder: "نام و نام خانوادگی را وارد کنید",
          type: "string",
          multiData: true,
          name: "نام و نام خانوادگی",
          key: "fullName"
        },
        {
          style: "col-12",
          show_in_table: true,
          placeholder: "سمت را وارد کنید",
          type: "string",
          multiData: true,
          name: "سمت",
          key: "title"
        },
        {
          style: "col-12",
          show_in_table: true,
          placeholder: " تصویر اصلی با ارتفاع 586 و عرض 460 پیکسل",
          type: "image",
          multiData: false,
          name: "تصویر",
          key: "image"
        },
        {
          style: "col-12",
          show_in_table: false,
          placeholder: "جایگاه را وارد کنید",
          type: "number",
          multiData: false,
          name: "جایگاه",
          key: "order"
        },
        {
          style: "col-12",
          show_in_table: false,
          placeholder: "رزومه را وارد کنید",
          type: "ckEditor",
          multiData: true,
          name: "رزومه",
          key: "resume"
        },
        {
          style: "col-12",
          show_in_table: false,
          placeholder: "آیا عضو هیئت مدیره است",
          type: "boolean",
          multiData: false,
          name: "آیا عضو هیئت مدیره است",
          key: "isManagementMembers"
        },
      
        {
          style: "col-12",
          show_in_table: true,
          placeholder: "",
          type: "setting",
          name: "تنظیمات",
          multiData: false,
          key: "",
          edit: true,
          delete: true
        }
      ],
      bigData: {
        persian: {},
        english: {},
        both: {}
      },
      title: "برند",
      editedId: null,
      apiRoute: "Manager",
    };
  },
  mounted() {
      this.loadItems();
  },
  watch:{
      item(newVal){
          this.bigData = newVal
      }
  }
};
</script>
<style></style>
