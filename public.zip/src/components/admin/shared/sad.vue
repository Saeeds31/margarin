<template >
<b-navbar type="dark" variant="primary">
    <b-navbar-nav>
      <b-nav-item href="/admin-panel/about-us">درباره ما
      <svg id="_013-factory" data-name="013-factory" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 512 512">
  <path id="Path_43" data-name="Path 43" d="M497,302h-6.758L471.884,155.14A15,15,0,0,0,457,142H407a15,15,0,0,0-14.884,13.14L373.758,302H350.242L331.884,155.14A15,15,0,0,0,317,142H267a15,15,0,0,0-14.884,13.14L233.758,302H212V197a15,15,0,0,0-15-15H15A15,15,0,0,0,0,197V497a15,15,0,0,0,15,15H497a15,15,0,0,0,15-15V317A15,15,0,0,0,497,302ZM420.242,172h23.517l16.25,130H403.992Zm-140,0h23.517l16.25,130H263.992ZM30,212H182V482H151V417a15,15,0,0,0-15-15H76a15,15,0,0,0-15,15v65H30ZM91,482V432h30v50Zm201,0V452H402v30Zm190,0H432V437a15,15,0,0,0-15-15H277a15,15,0,0,0-15,15v45H212V332H482Z"/>
  <path id="Path_44" data-name="Path 44" d="M357,362H337a15,15,0,0,0,0,30h20a15,15,0,0,0,0-30Z"/>
  <path id="Path_45" data-name="Path 45" d="M437,362H417a15,15,0,0,0,0,30h20a15,15,0,0,0,0-30Z"/>
  <path id="Path_46" data-name="Path 46" d="M197,60H402a15.017,15.017,0,0,1,15,15v30a15,15,0,0,0,30,0V75a45.051,45.051,0,0,0-45-45H197a15.017,15.017,0,0,1-15-15,15,15,0,0,0-30,0A45.051,45.051,0,0,0,197,60Z"/>
  <path id="Path_47" data-name="Path 47" d="M137,120H292a15,15,0,0,0,0-30H137a15.017,15.017,0,0,1-15-15,15,15,0,0,0-30,0A45.051,45.051,0,0,0,137,120Z"/>
  <path id="Path_48" data-name="Path 48" d="M136,372a15,15,0,0,0,15-15V337a15,15,0,0,0-30,0v20A15,15,0,0,0,136,372Z"/>
  <path id="Path_49" data-name="Path 49" d="M76,372a15,15,0,0,0,15-15V337a15,15,0,0,0-30,0v20A15,15,0,0,0,76,372Z"/>
  <path id="Path_50" data-name="Path 50" d="M136,292a15,15,0,0,0,15-15V257a15,15,0,0,0-30,0v20A15,15,0,0,0,136,292Z"/>
  <path id="Path_51" data-name="Path 51" d="M76,292a15,15,0,0,0,15-15V257a15,15,0,0,0-30,0v20A15,15,0,0,0,76,292Z"/>
  <path id="Path_52" data-name="Path 52" d="M277,362H257a15,15,0,0,0,0,30h20a15,15,0,0,0,0-30Z"/>
</svg>
</b-nav-item>

      <!-- Navbar dropdowns -->
      <b-nav-item-dropdown text="وبلاگ" right>
      
  <template slot="button-content">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 512 490.302">
  <g id="_022-tv" data-name="022-tv" transform="translate(0 -10.849)">
    <path id="Path_86" data-name="Path 86" d="M497,81.194H292.476l44.739-44.739A15,15,0,1,0,316,15.242L256.263,74.98,196.525,15.242a15,15,0,0,0-21.213,21.213l44.739,44.739H15a15,15,0,0,0-15,15V447.088a15,15,0,0,0,15,15H62.415v24.063a15,15,0,0,0,30,0V462.088h327.17v24.063a15,15,0,0,0,30,0V462.088H497a15,15,0,0,0,15-15V96.194A15,15,0,0,0,497,81.194Zm-15,30v90.069H391.869V111.194Zm-452,0H361.869V432.088H30ZM391.869,432.088V231.263H482V432.088Z"/>
    <path id="Path_87" data-name="Path 87" d="M436.934,372.023c-7.846,0-15.363,6.9-15,15,.364,8.127,6.591,15,15,15,7.846,0,15.363-6.9,15-15C451.57,378.9,445.344,372.023,436.934,372.023Z"/>
    <path id="Path_88" data-name="Path 88" d="M436.934,311.957c-7.846,0-15.363,6.9-15,15,.364,8.127,6.591,15,15,15,7.846,0,15.363-6.9,15-15C451.57,318.83,445.344,311.957,436.934,311.957Z"/>
    <path id="Path_89" data-name="Path 89" d="M436.934,171.26c7.846,0,15.363-6.9,15-15-.364-8.127-6.591-15-15-15-7.846,0-15.363,6.9-15,15C422.3,164.387,428.525,171.26,436.934,171.26Z"/>
  </g>
</svg>

    </template>
        <b-dropdown-item href="/admin-panel/weblog-categories">دسته بندی</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/weblogs">پست ها</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/weblog-comments">دیدگاه ها</b-dropdown-item>
      </b-nav-item-dropdown>
           <b-nav-item-dropdown text="پرسش های متداول" right>
        <b-dropdown-item href="/admin-panel/faq-categories">دسته بندی</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/faqs">پرسش ها</b-dropdown-item>
      </b-nav-item-dropdown>
      <b-nav-item href="/admin-panel/contact-us">تماس با ما</b-nav-item>
      <b-nav-item href="/admin-panel/cooperation">همکاری با ما</b-nav-item>
      <b-nav-item href="/admin-panel/prize">جوایز</b-nav-item>
 <b-nav-item-dropdown text="آشپزی" right>
        <b-dropdown-item href="/admin-panel/recipe-categories">دسته بندی</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/recipes">پست ها</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/recipe-comments">دیدگاه ها</b-dropdown-item>
      </b-nav-item-dropdown>
      <b-nav-item href="/admin-panel/settings">تنظیمات اصلی</b-nav-item>
      <b-nav-item href="/admin-panel/sliders"> اسلایدر</b-nav-item>
 <b-nav-item-dropdown text="محصولات" right>
        <b-dropdown-item href="/admin-panel/product-categories">دسته بندی</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/products">محصولات ها</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/product-feature">ویژگی ها</b-dropdown-item>
      </b-nav-item-dropdown>
      
 <b-nav-item-dropdown text="کاربران" right>
        <b-dropdown-item href="/admin-panel/users">کاربران</b-dropdown-item>
        <b-dropdown-item href="/admin-panel/user-role">افزودن نقش</b-dropdown-item>
      </b-nav-item-dropdown>
      
<!-- 
      <b-nav-item-dropdown text="User" right>
        <b-dropdown-item href="#">Account</b-dropdown-item>
        <b-dropdown-item href="#">Settings</b-dropdown-item>
      </b-nav-item-dropdown> -->
    </b-navbar-nav>
  </b-navbar>
</template>
<script>
import {BNavbar,BNavbarNav,BNavItemDropdown,BDropdownItem,BNavItem,} from "bootstrap-vue"
export default {
    components:{
        BNavbar,BNavbarNav,BNavItemDropdown,BDropdownItem,BNavItem
    }
}
</script>
<style >
    
</style>