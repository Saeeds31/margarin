<template>
    <div id="doubleLine">
        <div></div>
        <div></div>
    </div>
</template>
<style scoped>
#doubleLine div{
height: 1px;
background-color: #707070;
margin-bottom: 1px;
opacity:0.1
}
</style>
