<template>
  <footer
    class="footer d-flex flex-direction-column align-items-center width80 margin-auto"
  >
    <div id="mainFooter" class="d-flex width100 justify-content-between">
      <!-- <div class="width25" id="images">
        <div>
          <img class="width40" :src="samandehiImage" alt="samandehi" />
        </div>
        <div>
          <img class="width50"
            :src="enamadImage"
            alt="enamad"
          />
        </div>
      </div> -->

      <div class="links width15">
        <h1>سایر لینک های مهم</h1>
        <div class="lineBreak">
          <span class="large"></span>
          <span></span>
        </div>
        <ul>
          <li>
            <router-link to="/login-register"> ورود </router-link>
          </li>
          <li>
            <router-link to="/login-register"> عضویت </router-link>
          </li>
          <!-- <li>
            <router-link to="/"> سهام دارن </router-link>
          </li> -->
          <!-- <li>
            <router-link to="/"> همکاری با ما </router-link>
          </li> -->
          <!-- <li>
            <router-link to="/"> ویرایش اطلاعات </router-link>
          </li> -->
          <!-- <li>
            <router-link to="/cooperation"> استخدام </router-link>
          </li> -->
          <li>
            <router-link to="/"> آشپزخانه </router-link>
          </li>
          <!-- <li>
            <router-link to="/"> دریافت اپلیکیشن </router-link>
          </li> -->
        </ul>
      </div>
      <div class="links width15">
        <h1>لینک های کاربردی</h1>
         <div class="lineBreak">
          <span class="large"></span>
          <span></span>
        </div>
        <ul>
          <li>
            <router-link to="/"> صفحه نخست </router-link>
          </li>
          <li>
            <router-link to="/about-us"> درباره ما </router-link>
          </li>
          <!-- <li>
            <router-link to="/"> خدمات </router-link>
          </li> -->
          <li>
            <router-link to="/products"> محصولات </router-link>
          </li>
          <!-- <li>
            <router-link to="/"> فروشگاه </router-link>
          </li> -->
          <!-- <li>
            <router-link to="/"> اخبار و اطلاعیه ها </router-link>
          </li> -->
          <li>
            <router-link to="/weblogs"> وبلاگ </router-link>
          </li>
          <!-- <li>
            <router-link to="/"> آموزش </router-link>
          </li> -->
          <li>
            <router-link to="/contact-us"> تماس با ما </router-link>
          </li>
        </ul>
      </div>
      <div class=" width40 d-flex flex-direction-column align-items-end">
        <logo class="width15" />
        <!-- <p class="blackColor04">
          لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده
          از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
          سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی است .
        </p> -->
        <div class="d-flex width100 align-items-center justify-content-around">
          <p class="blackColor04 width80">
          ایران _ تهران- شهر ري-كيلومتر 3 جاده ورامين - شركت مارگارين </p>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            width="24"
            height="34"
            viewBox="0 0 24 34"
          >
            <image
              id="Layer_2653"
              data-name="Layer 2653"
              width="24"
              height="34"
              xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAiCAYAAABFlhkzAAAABHNCSVQICAgIfAhkiAAAAehJREFUSEu9lj1Ow0AQhZ0GKiQkOgoUbkBOQGioyQlIbgAnIDkBKegxJyA1DeYEcAOo6BBIFAgq3md5o42zfzEmIz3JzszOm5mdGafzdbWXReRE+gPhsGb3oPcnYRY63wkQjHXwVOhGAniR/kbAfklcBER7XUUdy87Wk82oymr+e50A5/fC9iqeLdsPPR/ZJDbBX50bHkh6AqXLbILHBmXxJVpUmcwJhlXdG1bGeYz7yE0Gz3rptum9KtE+BNSe8sSEmpqeZzZSAupBMJbxRcR7Lj0p20IrU9qQTCCgLfsBq0I6Ws8lsbOzFIKBVZo6CaW6DQWXQkD0ZOESMicLnxQpBKEMuAPuIkhwKe3ZP93BlAxiUcCdC+cCawBhVxEYZ0MyggDj94ghapyzMRFmJ2UhloPGATqBjmhTGMqBIejrJdQNTYjL7rO3aWxoViEpZFwO51q/BxAOhVBfp2RBt02NoeubnLLEfES5FAtL0fevoklX0cLU3cxKGYSPgB7n0un3FHE6DxGgS51Wr/MYgYk8tKuWal5PN/TPzrZlyrl8sx6oM90CQVBSCXDSFfi0QjIRzF5qjSAWrFPvy2BH1rvChsDzpsf7t35/E36E1+p5wbROgLNjYatRuFn2qXN3NtHaCUzgrZXoF95rm0DJTBJEAAAAAElFTkSuQmCC"
            />
          </svg>
        </div>

        <div class="d-flex width100 align-items-center justify-content-around">
          <p class="blackColor04 width80">support @ mmc.ir</p>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            width="34"
            height="32"
            viewBox="0 0 34 32"
          >
            <image
              id="Layer_2654"
              data-name="Layer 2654"
              width="34"
              height="32"
              xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAgCAYAAAB3j6rJAAAABHNCSVQICAgIfAhkiAAAAhVJREFUWEfNmD9Lw0AYxu3iJihOOkgnN0Fw0qkuboKOTtZvoJ/A+glUcDebq6td7KSTIHRzsZuTKHQQnXx+Ia9cr0nbNP984aGX5PK+v1yeuxytfV2tzIyJuq6jLPGpm59HJajFgMzrhmPpMAcAv3ZPJ26lS4n2X/ggTV05l4ApOs5UoGVFXBAgrouu7uUPdHzEOQNpqH1fMoSVO1HjwkBedVCvCAQjLxjIR0m+SHrWmoHsRf4ow6Q+DB4JXLOuRzD8lhG8km0pXF/86cuIMHMYoSKD4kAAEwYgi/pdlrpO5ZbapwWRBMobTtkoqN0HZFeNJelNupN+og5F+Cb0Q5R/Vr9b0iq1XRCu96W29B51zss3A35Q7jlpR+JtEEMgnGREHqSXqFNW3/h+4FUAwYhYxILYRTzz6HRuqZ3WN4Hucf2wpuNNJ+dEIOGQSdP6JskPMRzxr8bvmNY34/wwNUiSb9guNL2sHR3vS7Y+xPkhE4jd/KQGsqirgYheJLuW5IdcQKwgT27rjZ/YXR/iiuYGQiJ8w8gwCgYEAKOzIbFOpImR03fSRIB8T1HczZ8LyKTAo/r9L5CGUPnwVBldPnoYjLW/ymjbxuggo9myPAQz8MZAqhwVth09d6uIT/BLmdFRsXC74e9ZgWHX5O4VigDz9zxDIBQFgu8EUGlXyHHQ+IERYK8z8ImI+zfATwZMViAAUGL8AoBepZB5QlNAAAAAAElFTkSuQmCC"
            />
          </svg>
        </div>

        <div class="d-flex width100 align-items-center justify-content-around">
          <p class="blackColor04 width80">دفتر مرکزی 35811 - 021</p>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            width="34"
            height="34"
            viewBox="0 0 34 34"
          >
            <image
              id="Layer_2655"
              data-name="Layer 2655"
              width="34"
              height="34"
              xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAYAAAA6RwvCAAAABHNCSVQICAgIfAhkiAAAArlJREFUWEe1l7FOG0EQhnGTLhIoNKRApqFDCkqVNLk0oQEpiAoq5w3CE+A3SIpUNDhNUiYRHQ3uqFCQ6NLEFa6QkFJEcsX/nXat8XnPt3s+jzS6vbvZ2c//zu2uW/+/rC81aM+U67XLd6frvXwQk7/VMMieBl0rDDzS/a1z2kELgbxX5Cd52/X4rOtxzK9STCbfLIkF4toBTYUUQQD4GEh0o2dv5Q8RQM+dKkyT/zG2G1PVl0+oY0HO9LIzYyBgtiNAbMgT3Ww5p+2N2jm3MB6kCsIn6KnxIRGG8Kfyd3JU8oYyF/4GkEw3lwnJZ8FQH+T7Jx/KqQnaGIrsyG0xX+meQl4CJFYNy4oqABUt9NUwEAN6GGK8MtTJN/kIENTgV6TYTwXvBzq81DO8aH/0oO8eMk0Hcl8zqHZdFwQ1ymqFgdoOyBaoVcYCo0oPkB9qsHakWNnU2BxA2Gng3Xc5NcO7jgm+AIR1g/UjxVYUHLOmMOCRmQY7RXxFKIflU8PN3wSKvmJZ3GLNf0nE59PgOtrpGaauI+RIBaFmDg31qWuzAu+69hgkRZWBOm/EyuHiXum6Kqdvvm44y3QFNJ8a/7BsnwmNydSgTGNmQZaV9bccdaqszr4zM2dx90Wq2OW+p9g6+04QKHQe6SrypEoS974xmLITWsoi1whMGQj1whS9iFSGmuEUZwuYHKzYb+S0f8mBjp4aH0hnFjqusTZQII5lgU6ABOuq6vCMIiiTAlMFDQzqTWwRVSAkXQTM1Bk4BmSRMOMzcCzIomDGf1VSQBYF0yJxKgh9Uj/tquKtDeJhOHSnnuyKUHzq+U5eRxGbrKub2O0gpAwHcA7ic4OQI5OjTrtqDgrvJ/5Tz6uIz03doEzof3OIr6eHEytsUyB+MFQBqDNDnSmIpqYmNCZAdsMjZiD/Ku+HOjwCWQ+znC18dcsAAAAASUVORK5CYII="
            />
          </svg>
        </div>
        <div class="d-flex social">
          <!-- <div>
            <svg 
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              width="78"
              height="78"
              viewBox="0 0 78 78"
            >
              <g
                id="Group_2tw"
                data-name="Group 2tw"
                transform="translate(-1333 -6339)"
              >
                <g
                  id="Rounded_Rectangle_41_copy_3"
                  data-name="Rounded Rectangle 41 copy 3"
                  transform="translate(1333 6339)"
                  fill="#fff"
                  stroke="#ebebeb"
                  stroke-linejoin="round"
                  stroke-width="4"
                >
                  <circle cx="39" cy="39" r="39" stroke="none" />
                  <circle cx="39" cy="39" r="37" fill="none" />
                </g>
                <circle
                  id="circle_copy_3"
                  data-name="circle copy 3"
                  cx="29"
                  cy="29"
                  r="29"
                  transform="translate(1343 6349)"
                  fill="rgba(0,0,0,0.06)"
                />
                <image
                  id="Layer_2658"
                  data-name="Layer 2658"
                  width="24"
                  height="19"
                  transform="translate(1360 6369)"
                  opacity="0.2"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAATCAYAAACKsM07AAAABHNCSVQICAgIfAhkiAAAAbdJREFUOE+dlXsvA0EUxXe83wTxTMQfKN//w0iIUKG2lNBqva3z285spmo7o5Ocznbn3nvuc9ZkWZYYY2aTJOnoOdMeXJJfl9CaMGGF0XsRroQPe/apPTX6AYdCS/YRGLhkfFMCWyVCEIEv4VJoYxzv94VRoS7ciAiBviXjU3pZEcYCfrR0/io8QDAj7AnjVqmt/VokCPUsEazoxW7AOMek51w2mi5FR3ox7SkS5pPQEDooUB8RbOh5O4KgKnF0E2OLvKrnHf7/oUyo4M06sRAgwLkz2cXB3CCeU4dFYSnCu5AI6YHg2RFQA4o8YhEyEDp/l8CJCIg4jwDDFHk+pBl5TnOcuplyNSBFkITaL4aDNq85wZwgD6U7zXQIO1ENs76ldCybNEXXrkdAsRl/Cj1sJA3Zq/qe+QRM6YHgBu6/EXAHUdzC+54IbJrmtDMP/tDFEl3I+P1v4SKCImfGEAFpAqGhcmr1souyj8BGsqydW5O0hVYqgVrZVc8ccKeTEjyfFJjomBQxUKkM3w3ywF3X3EV4HdOeGH4Ubt20DiTw2pR0MM3sRMJOu9IdgNFvCnz58msgZv0AbOys9+kU3K4AAAAASUVORK5CYII="
                />
              </g>
            </svg>
          </div> -->
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              width="78"
              height="78"
              viewBox="0 0 78 78"
            >
              <g
                id="Group_2apa"
                data-name="Group 2apa"
                transform="translate(-1421 -6339)"
              >
                <g
                  id="Rounded_Rectangle_41_copy"
                  data-name="Rounded Rectangle 41 copy"
                  transform="translate(1421 6339)"
                  fill="#fff"
                  stroke="#ebebeb"
                  stroke-linejoin="round"
                  stroke-width="4"
                >
                  <circle cx="39" cy="39" r="39" stroke="none" />
                  <circle cx="39" cy="39" r="37" fill="none" />
                </g>
                <circle
                  id="circle_copy"
                  data-name="circle copy"
                  cx="29"
                  cy="29"
                  r="29"
                  transform="translate(1431 6349)"
                  fill="#f0f0f0"
                />
                <image
                  id="Layer_2582_copy"
                  data-name="Layer 2582 copy"
                  width="24"
                  height="24"
                  transform="translate(1448 6366)"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABHNCSVQICAgIfAhkiAAAAxNJREFUSEuVlnfIj1EUgH32TlKUMpOR7Cj6SoqsjIg/jEKSjBLKzMgfFMpMkbJKiUgISbZIRp8RsqJsISPr8zy/7tXr9vPDqaf73nnuPfecc9+i0tLSMok0o74T2kA5eAlbYGY68F/qRYmCuky6C9XD5GuUh+ETVIXa8APuwDG49DclqQJ3OhpuwzwYAAOhRp6FPPpzWAtLoDJUhHfZsVkFZel4DBfgEKwMu/7bJu1/AFNhcRi8hnKz31kFDakPhTowKwz8SHk+KOpEWb6Atg/0zYYVUAFOQ3Fqoik0rg6LePyW8DrUO1KegUoZJd7HN9A0yluYn1ljTnoCLzjuchjfu5Idb6A+IbSdohwDz2BEWFRFJ+AL9ISSrIKDNPQJk73AVnArUTCd+nJ4BJo0K5OoeOHOdZymuhcV1KTyAuJRneiAGcki2rUbbILxSZ9epAdp/yPQHO5GBSOpbEsmaFsvex1otlUwNow5StkrGd+C+g0ogjewG65FBeupTEwmxKpBZkR7uvdQJSwymHJ/Zs5Vvo1+xcvvB2ejgu1UvKhCcp/OJtAbjBMXMWb0tq6ge0fxHjrAlahA82imKHrBRrgIfcH48I5UMBxyQVRAVNDF+SqoxYcRaAwo7qwYzmYWMEq9g89gHLiBh6Bz1MujyDUawBMVmDkNoBhgN/nWRVMxiFzQdNIezLLKgoCXG8VLNjHmUoW7mgtzQuN1ytZ5FOiCJj1teznpt94u07aP70FRgfZy13vBXPI9DC7JTBjF91bQdauBJsqKcTEuNGietpCb7wkcbHAMAd3VN8EkZzY9B16y6cFYcDPd4WSiQP83byk74JfDqCCmCO3msXxICmXNV/SbZ6KZsvnJh6g/3ANPmzuBAWRK9uLsWApGr6f6k2gG3dZXLj5GnmIPeH8GYU6yyU5TaEfzjc/kAWhUQEnscqfG0RPQWXT5hfkU5FtL208GfwQ8aXRFHcF34njYjOM6g+31wRSek/TB+dOGNYXuaVB9BXOTJ+4BjTOTFmV3/z8KUsVNaZgGXrYB9RSWgTntN/kJBYv1MMttqb4AAAAASUVORK5CYII="
                />
              </g>
            </svg>
          </div>
          <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              width="78"
              height="78"
              viewBox="0 0 78 78"
            >
              <g
                id="Group_2ins"
                data-name="Group 2ins"
                transform="translate(-1509 -6339)"
              >
                <g
                  id="Rounded_Rectangle_41"
                  data-name="Rounded Rectangle 41"
                  transform="translate(1509 6339)"
                  fill="#fff"
                  stroke="#ebebeb"
                  stroke-linejoin="round"
                  stroke-width="4"
                >
                  <circle cx="39" cy="39" r="39" stroke="none" />
                  <circle cx="39" cy="39" r="37" fill="none" />
                </g>
                <circle
                  id="circle"
                  cx="29"
                  cy="29"
                  r="29"
                  transform="translate(1519 6349)"
                  fill="rgba(0,0,0,0.06)"
                />
                <image
                  id="Layer_2657"
                  data-name="Layer 2657"
                  width="24"
                  height="24"
                  transform="translate(1536 6366)"
                  opacity="0.2"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABHNCSVQICAgIfAhkiAAAAcBJREFUSEu9lllPQjEQha173B/cl/jgnhh98P//B+Maoz4YEAP6IEQUBcTvQJv0wt1QsMkE2pk5ZzrTTq9pNBoD/jDGjDBfQGaRUWQ4YNA5qbH0iZSQZ/CqATyfAPBllCvIYAJolPobRQ7MvDMwjgDwTRbnfwnc7vYC7oMWmwQ28rUegTuYrHZimCnnh39IiwNUHca8IJWuCxGs2rwnbaBiiyk7AY17DnWiPSUTCtQneRLBPjIZg67Toe1++DaATTBXWmfsep3foTacsgiOkaijmAc4C9g0NoteIGX+S/eGbsPqwmKsieAkIvoSALcALKFfj7BpFdKYHW8nAdM4giu7s92E4tygV0EPwuyiCCpEdklkWzjNJRC8YnsfUuCmWxSBczrCRsc4blQhOINgGyO1l1QpKuJ0h1Magi9sz7sl6HuKtM1rRE1vrx9FFmaaY5ohPQXSo5Omu9Ixki5aAYAMAFN46j64G9/VRUvTKh4hevfDs61CFzA0cmvbbBVpm526pRqehhqd39SiypTrZbtuJ2m1a/vgxPWbhEMUqW71qX95Ml0MtnOqJr1/9D0S99mih0SFTPvZUsRWj33gs+UHl6bDhE2M0U8AAAAASUVORK5CYII="
                />
              </g>
            </svg>
          </div>
          <!-- <div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              xmlns:xlink="http://www.w3.org/1999/xlink"
              width="78"
              height="78"
              viewBox="0 0 78 78"
            >
              <g
                id="Group_2tlg"
                data-name="Group 2tlg"
                transform="translate(-1597 -6339)"
              >
                <g
                  id="Rounded_Rectangle_41_copy_2"
                  data-name="Rounded Rectangle 41 copy 2"
                  transform="translate(1597 6339)"
                  fill="#fff"
                  stroke="#ebebeb"
                  stroke-linejoin="round"
                  stroke-width="4"
                >
                  <circle cx="39" cy="39" r="39" stroke="none" />
                  <circle cx="39" cy="39" r="37" fill="none" />
                </g>
                <circle
                  id="circle_copy_2"
                  data-name="circle copy 2"
                  cx="29"
                  cy="29"
                  r="29"
                  transform="translate(1607 6349)"
                  fill="rgba(0,0,0,0.06)"
                />
                <image
                  id="Layer_2656"
                  data-name="Layer 2656"
                  width="24"
                  height="22"
                  transform="translate(1623 6367)"
                  opacity="0.2"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAWCAYAAADafVyIAAAABHNCSVQICAgIfAhkiAAAAglJREFUSEutlllPAkEQhFkVb8U7njExHlGj//9n4IOKRsWoDyhCvEVUsD5oyDqZZUGZpDK7sz1VPd09DUG1Wk10ewQa4kyKuxx0U0C8oyKeFiaFXqHwbwGRJo0U4kEnGpU/CVgIUiKbEcYFQuIbHx0JiBgP8RTgedwoxgqIlFhOGemIh7GstZzwKmw7328iBUQ8ZiGY0NzjIf404nsVSkX2hGvVsTv9JSCjfvMW44GI839p/Va4gxgb7cOJNR6dPWkWAGUFKV5HjSaxGYxI4FnkJHndQ17S90PIN2OIvxsea+ZW4ggVdCEMCRuCL4RFCWQR2DFD13OOTygAz1TOoj2faKaKcI4i8I1rCdwh0Geb8YqbiJd5gcrAe4gXBPJDxUCOx1u2N4I/cSKBFzfJeIMoxJQmxI1kkwPIcQDyVvcAm3Stuny9SIkjtoSuMQhRRqA0IXdbgnuKd/EesdjqHoRz86AN5xLmIg1HxSS0XpD9ZZzAvAyWbNO1ZvJCUslT3KglOE6ApO4Z07Hmd3te1jwXo5CRAK0jOkS1j0FAvMnHgbAilLUxp/VZe/d10WaC2xGAKCXSM5Hu6pnkZvVetB8X2oNbTW/6zolro2U3tU5Kn3kS9gX6D/mob673LkTCXTYvm6u2BEJEeD6gjY+NtdA3Lh154bSU8ansSh0JuKS+dzttReS//kX8AB3o3K+1FOFNAAAAAElFTkSuQmCC"
                />
              </g>
            </svg>
          </div> -->
        </div>
      </div>
    </div>
    <div id="bottomShadow" class="footerShadow"></div>
  </footer>
</template>
<script>
import logo from "@/components/front/shared/logo.vue";

import samandehi from "@/assets/front/images/samandehi.png"
import enamad from "@/assets/front/images/enamad.png"
export default {
  components: {
    logo
  },
  data(){
    return{
      enamadImage:enamad,
      samandehiImage:samandehi
    }
  },
};
</script>
<style>
.width15{
  width:15%;
}

</style>
<style scoped>
.blackColor04{
  font-size: 14px;
  text-align: right;
  margin-top: 15px;
}
</style>
