<template>
  <div id="tour" class="d-flex width80 justify-content-between">
    <div
      id="content"
      class="d-flex flex-direction-column align-items-end width50"
    >
      <svg
        data-aos="zoom-in"
        data-aos-duration="1500"
        
        data-aos-once="false"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="120"
        height="122"
        viewBox="0 0 187 191"
      >
        <g id="Icon1" transform="translate(-623 -1302)">
          <circle
            id="Ellipse_584"
            data-name="Ellipse 584"
            cx="90"
            cy="90"
            r="90"
            transform="translate(623 1302)"
            fill="rgba(177,14,20,0.05)"
          />
          <image
            id="Layer_2611"
            data-name="Layer 2611"
            width="183"
            height="183"
            transform="translate(627 1310)"
            xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALcAAAC3CAYAAABQbs+fAAAABHNCSVQICAgIfAhkiAAAHLRJREFUeF7tnXXsPEtWxVlcH7ZogGVxlxAC/AGbDUETfHF7j8AGCMGCLrKExQMsLGRx96DLHwSCZBe3P3CHh7sEd7nnx9RLvfu9t+65JdMzPd1JZaa7q6q7b33q9KmanplHPO2+Rz7TsRwR2GMEHnHAvcdmPa4JETjgPjjYbQQOuHfbtMeFHXAfDOw2Agfcu23a48IOuA8GdhuBA+7dNu1xYQfcBwO7jcAB926b9riwA+65DDxisLr/HSx/FK8icMDN4TAKLXcUPtfRCYhYHXDfDdKlgUw0470sB/AqUgfc8ggCS8+V5bt52G8R7r3CHPW9m4P9VuC+VaA94G8C9L3DfUDd1vNdQ75XuA+oI5Py8P27hHxvcG8J9axjbwnalsfOdUci917gngUWEbLNZlfOCd45j8XEvCvPHuBeDfbq+rsa7gzz2lcP+DXDvQq6VfX2QsyWWwXjqnrZ6+rOd61wrwBwRZ3dDTNQcAWMK+ocuESu6LXBPRvA2fVxUT9frtlQzq5vaSSuCe6ZIM6sa2kDTap8JpQz65p0eXY11wD3LBBn1bO0Qc5Q+Sw4Z9Wz7JIvHe4ZQM6og22A0WOdE5gZx5pRBxvbdL5LhXsUEgRiRh06oCvqzDTaCphm1DmjjkwcqLyXCPcoQKPlS+Bm1UM1xECmWWCN1jNafiAE1+G5R4AaKbsCaPZ8ZkIxo66ROkbK7hZuFgQrACNle+zL6PF6GzELTja/Pq+R8iNle+Nzp9wl2JJeWHrLZYAeOca0RmpUxELE5rMO1Vu2t9y0uG0Ndy88K8v11j2tUTorYmBi8uwG8C3h7oGopwyj1L311iDMqAP19QJYn0tUR7Tf61895XrKdPbvhxfbCu4eEGaXmV3flAYJKukBpVVmdn0zO8VwPLeAOwtVNn+k1Jn6MnlHVLwHsqzKbw157zV2Q35uuLOwZPO3wGbrYvIxebobxSjIgMHkaXUItnzG/sycgUnH85xwZ4GYlZ+pp5WHKZ8O/IQCo0rslc9Cvjp/d6jOBXcWkEz+ETC9spnjt4If1ZMFI+tpo/pHO0g5n+g4myj4JcIdAcF426iOGVBHx+hWHFUwA06vGveW67UomWvqjuM54M5AMCNvVsmZYzJ5SiNk8q6EwwKoR6mzILL52XwXC3emodm8vaqry0XHy3aS7kYgCvZA6VmGCKpzqnh0LkRo/CyrlTsCKKt2PWBnoO6pf6gBBgqPKnNPh2FhnJ2vK0wr4T4H2NExWLCteqK6sx0z20AsINb0XkZ9s5Cz5zU7XzZ+S/9BmIGDyYOLysLXC3V0PtF+71yZhmFgiPLo/SzkuwR8lXLPhGAF2L3wr1brWVN9PZBvCXjUaRlxuJNnBdxbgd0DLOuxmWvSwWXL9DQs67cZyJk8lvXxBqwWiMw1MnlSkF8y3BnFZsCu8zB1R3BG+1MN0cgcNToDZ52H6RgrVDx7HcPx2wJuBgoGPs8iRGV79re8NHM9PQ3F+uXMlF8G8tmAR3C37g498Zs+oIwaOtqfHTxm1LgH6qhMV9AHCjEqrSFplRlRcfZc6suNAI/2p0I3W7kjeHv2M744grBlW6KyLyARfSNJr3pKryavryTpuVKRvpv5X2XTb0n69Sr9lLz/+1PWqKEjuFiV3i3gM+HuAbdu8ggyL29UzgM7Kvc8csAPlPSRkp5/EGS2OMB+sqQvkQT49cJYlYxStzpA1HnKubH5vPzsNbIxfCjfueCOwMcJMYNCna8FaEatS168Pquk95H0cZJeIh3ROQX+TKr5bEnfIOm/HCWPFNeDLgM/Dh3dAXQeaz0LcHTXoqI8C+4I3uz+HivS8t81vHVgdJnnlJ3fJemNjej9pWz7NUmwEX+kGp0KtsqEY7+MpFeRBKvzokYlPy7b3knSvxn7WNX18jHby2HPDfjVwH3pYJfzg2J/i6S3VCD9gax/mqRvPwEd2Zle0B8nBT9B0qNUBd8v6+8lCQo+W61ZdccpRYBH56bjkp2NScf1HMrdgnuGFfEUO9pe739midxXSQJg9fJUWXmipP+sNr6IvH9NSSjjLVGHRrn/lvQrkv76VAka+9klfYqkD1IVf6esP/5Upuxi7UXJx4Ls5e8BPFLgpYDPgDsDr4aBgZuxG6g3grnOo/NCmT9UndxXyPpHn7a9tLx+gKTHSnoNdawG4+EuNC4Af7okHO+PTyU+R17fX5X+Iln/5GobYyusPNG2COKsgvcCHHWMMLhbwr0abGaWBHkwaPxlSVDNssAKvPtp5dHy+r2SXuq0DnsAta3VPAy0keHZZNsjJcEOYQHYby/pQUk4r2+S9BZVuf+Q968jCYPNeokgj2COyuNY7F2inFcrvw6FB/FFw51R9MjHtjqCpdiZbU+SaGvVhkL/giT43ydIwkDyx04A/o3R2GgwxorohkWZF5aEjoNBLAaWnyXp9yW9tqQfUQW+WNZ71HtrwDdR71HlzgBct1Ok2iNWJAM25q8B7vNWJ/ej8v7tTrB61xedv4Y4s466AQPSd5+gL+X/Sd68liT9QQ8L70g+nAOj8uVcN1fvVXBnoG+p9grFruuEp/5ERR68LqYD2WNrcHsU3APiHWTHl6sDfIasf57aZg0C9TYmTw1w1BFasGcBX2JNtoa7145k1LkEGmV0uZ+VbfgovSz/I29eWdLfVttKmehc6+No4Nl13cgvKAUxr17PzPy2rONxAA1XWW9BuTXgPfak23uPwJ1RZ6/hM+poQZbZpsGGz8VMRb3AZ7/paYMHdcsyaYgZFY8a7wekUgwk6wXrfyKJgdXLEykzU3c5J8+ueB3Q6uzT1XsF3Cz0PXZklmKjHnwwgum1esFzHZ+u4MZqBDTrzXsaFQPaD1MFP1zWMZui4dKQZddrGC24rf2tc2Dgt/LUlxt1fium97adE+5oEOYBFG3XCqvze+tfLdcPT1svbyMrP11tYNRbw+8GO7mjNOobSrnvUWWfJuuYd69hK++zQEf5rWNE0EaDyaxKdwG+Fdyr7AgL9rNI6+Bx0xeqoPlnef+KkjB/HUE9otQR47ohMR8O342nFMvyd/IG04YYI0QDR2t/BHSPZak7gQVjy7pYnaWO01nhzjYuq9pevqwdsdS83va6ErkfVpTB28KqsD4exaPrikC29luq93WS8c1VZnzAgzGCBVUG6KhzeNC2PHldxgL3opV7BG5WtVt2pAV7BDaCjWe09RQgHnGFVWE7kgV3zV9r7KGhjmYRHpACZSxQyn6mvPlCSZ4KzwS8Z3A5U72vRrkZda7ByYBcynk+HNuR8HE6ptPwCeDPSPrF02t5tLSl3hbU2c5ew82oGL718/qS8KklXh8rCWMDPA7bgrh3X628nrJbeept+n20r8Qk6hRaGNz1Xs9tNSbTwFnVZlTU89megpcn7/AU4IOnyBTo2U6VAZxujCpjNCB7lOR9P0mfKgljhF6IUW6F/7aUPoK9BbdVNozrNcPdUucCX53Hy//ikvmtJD2HpJIHCo45cHw0jweWWhZJBzljR3RZQIHOh8Einj7ElycKKP8u7/FAF740UTd2yzOz0Ee++yrV+1LgZhS6AFuAqNU2AzPK4RO/x0i6XxIGZuXJPA0bVBGAY+AG64LX35WEWYp6ad2RdJ31Os7j5SXhQxk8M4JXfBEZMyTWgicSf1DS10vCg1xFeVu+uwYzCzvOwVL3sr2cY48n13XU1zvFmvTAzdiPcqKe4mF/pIYZr50BHWr4NZLerEVdYx8eXvolSYC9AK8fQ9XFy7Xg8VoADO+MBKDrKb7MKWG2B3PdUPQIWg9wa7sGOlL1GlLdyTT81joLspWvGa9ZcDPAZwaSjJJHg8bSgep8AOkbJVnfkcyApfP+1Qn0X5XXP5dUrAO+Fwnb8+onmPEtnpnLT0hl90v6l8mAtzqLBXPksVtjiJuBuzVLwcJcoNZwP7dswNN+mG3Y0/LzcjHvJgk/BdFSaEa9NbiRaltKHW2rj6Hfl3ZhgW+240rlnmFJPNhZ0Ot8eJQVXwTY44I5e1itAgsDMpPHg51Vb8ameHZjGPCt4Wbsh1ZiT5m9mZEygMS88MvtkWy5pgclvYmkMtCtB4HR+4xfb0Ft7fO2nUW9rwFu3QF6VBsfXX/zTsEul3W/vPkhSZE1YRS7ZUe0Gkc2JPLjy6xJFm5r4JgdTLKzJC2Ii3p7al3vRx48Hqqfzdgb6wD7gRPcGuBIvTN2hrEkWTvCWpDUjMk54GZmSSJvbcHcsid1fZhL/h1J9+2NZnU9/yjrmJUpINevHrws9BroGertdYByWSzwbrOugpsZTGbnsVswa6Wu1/E1MkyZ3cKCbxHhUd4I2mh/pOS96q2B9SxLXX/dbheh3Cvgbnnv1mDyPSU6X3ALZMs14gvP33q6VgtgdpsFt6feFqD1cayOYKkzo9QXDTczj12rbgkCyjH+2lLwz5eN730jcOO3Dj/2pNw1oD1Qs7MouiN4MHudwALd23b1cI8MJHUHwPozJOF5jVtYfkMuEs/KaN89Cjqj5BbU7ExKXbZuJ0bN3XZd7bl7BpMW3Jnpv1rln0+uHINJDCrxS1F4FgQA/OZp3bob1OpfB65117EC7M0iWXkjRbIGcPilKownkPCMCr4yh3luPE2I51+YGZOsomuALXW3IPe2tbZngDcBH4U7mgZk4Y4Gl4wlsfLgg42vlfQUSfihyfrx1dIJWpaHuYtYHSDaVu/3BlklT+RpsR+PyeL57g+WhIepfvIEtzdj0lL2ApXuHK3tep+3bgG7bFC5Au7MYDKaAoxUvDWQxD781DAeZIJqF4hfVt7jiTw80FQWD2Ls9zpoBuA6L/s+uiX/hVSEH/D8wwpkqDke1sIDXC1Vziq2B3oNazSI9CC+CLgtlY62tRS5Bkfny9iQUk+txHobHnP9eEn45da9zXf/g1wTfhj/cyXhSxYzoLbqKCCzVqQ1gLS8eN1RigBEHbwpFBnljkDWKqhVr+VZWZh1h7AshVZzfNMdv476CkYk8APw+PAD/1imFwQWNgbf0LmGBV+iwBef8ay5th1Z4GuQI9VmYa/hPeCWaLT8cAHdAxzbX1LSMyR5av0Rsg8/cINHYeufLIOVeV9JeC4b33zB72hfw4KOitmSP1WAa1gjL17nz7y3ALZAZuGu6yvxt9TcbJtrU+6Wx9awIy8+0Hhsg8oPkX34XuK3SXq9Uz6ADfuCP3WCnXn6FcGNS8BPMOPf2LTitgaRMwaYuhN46xpYD3QP5ouA2xuIef66hrNcGDuToaHH+ttK+soG2GUXfr0Jv6aKpYCNQRrA/lJJs7+1Q5zScBbMmnzfCfCMRamB7PXdGtZdKvco3NmZEt0R8D+ODyhM8JNpGHhhLhi/+VEv+B5krdjXCjauCf9f+UkO3BbAnifXeev18l6/ZuG26qnbRSv1LpR7FG78PBoGk2UB2Pi5tJ+ThC/q4rUsABtf1SpW5Mvk/TUqdrkefFiFf4eIvHUNdeuLDrMGldYMyi7h9mZP2JmTaKYEoJaZjgI2fmweP4IJVS9/6KTBhmLjw59rXvCNePyIfuS7W7MoBTqrDg0kO2Nys3BHSo2ARkCXOvBxOz7kwAKw8WQglBrb8bcb5UEqzCpoxb52sEunfLS80Wrc67890K3tlhJ78Jdz9aCv69J5Q/FZOVsSee6WQlsgs3CXDlDgfqIUxEfvBWzMJGAB2O8iCX+Rh8Ej/ntmL2Dj+gC3B3NLsdmBZGRVLMgz21owU757Ntx6JqScoLV9BO7WlKCG+zvkJKDWHyXpPU4nhL/ceFdJsC74kcm9gT0CdwHQ8+v1fuu9BTA7Y2JBy24rrD30em64s5Cz89q4oAK1hltfNJQaYBfFhqrvSbHL9baUG3k8y3LAfYqgZz0KbFq5t4YbQL+zJCg3rAjmwfcIdqTcq+COlNxS9Xqbfm+te9tuWrkL2EWxAfZj7kRkPxsi5V4xuNwN3Fq1PbWut2+l3PjkEf+rXsDGb3PvGWxGuQ+4KyFrWRBtPy7NljxVTgh/uwErgr8G2TvYB9wSgZEB5TUpNxQb/x/zOElvsB/n0bySyJasGFAetuTUJOeaCrwRlu9c5gH30+6jH1WeYUss/81+3F7K6ulBax3byoc4B9y5Ly/U6tvzgU4pb71G2+r9pd0ufp47C7UFsq6jnte28uP7hS92o2TjSxawX8wnlIw9sezGik8oLxpuC+LCV2RDWKDrfC0Vx49f9v41yLX3CfwFIb4Nv+LBqQj03Sp3Bm4Ncw/cGvQa9o+RnfjI/RYXDJ6frJS7hlIrurXPg9h6CIp9KtAC39tW2u1ibMmWcGvQ8YVgKBim/25pwTfg31rS7ym4Rx6WiiwIC/eMR17rztBs15GpwBrk+iDafpR91vbim+s8+oOekedLHi8VP+mWyD5dL+byo8ddI7VmB5NaeVsPSd0c3JbaM0Brpa7Xy3s85grvjZ/2vYXl6XKR8NoAu4A0CnndCaz3EdzRE4G6vG6ni7QlWtk95c7ArfPWyu/NngBw/MTYEyTt1aLAiuC7oVDs1gzJLLW2bIoG31uvYS4ge4pu5fW23RGvlbZkFtwW0GVbS+E1+Pin3neUVP7cFD87ds0LpvvwF95I+O0VeGwN1IznR2b57RpKS80zIFtqfvFwW9COwF3X5ym7pf7MeejOa6172+qG0A3lrWsgvHVmJsQbXNadw4N6ZPBoKbQHeonRVdgSDWk5eWtQ2QKaVW0L7GhbVLeG1Rs8M1BrpWk1YhZsDakGtdUBPPW3tms1jvz1TcJtgc9+LJ+xJi31bqm1dy4e7HdukYkN0S07UmwPThbojGKznU53Au/Oxag0ZUnuNczAsyUtdcpOB1qQzIA7UmrGkmjovTuQFQ/9PI7HeNaaWNagBaVlQyJ1jxTcAtazLLuEm7mNZ+e/Leh71FuD31JuD+hZtsRTo9Zt3INZQ5uBmKnTg7rHkrSgr/d5St+8IY4qt6fe+oOY+iR6pwQ1YMxceBb6HsC9DtwMfGPniC3x1Nbz3JE6twaPWZU+q9++1yiDtmQV3J4VmGFVGCvCfHLKXLtmuJx/yze2LEoLNhbslrJbdbS2MdZkpiXx1NzUigzcmcYcVW7LBkR2xFJdrdxZtW+dx2zF9m69FuytQaWGqR5IZpSaUW1dnweypdoaVGYweRFwtxreA3+192bgj+4YFuwFSmvwOHtAySilZUF61XqmaltgetCXmLLAn1W5I1VjfHdWvXvgbVmUWaodAc5YlFnqHSl3a7+n0qMDyZYaXzXcXifQ6s6ue7ajB3xPxfU5M+umsqiN7HRgj3pHUEezJMwxLfitcpYqZyBuicHDQjrDc1uNa92qtYLNVG+tspE/j/bPUO1IsTXwmelAVkU9aKPtWTviQezN/Gi1vgm4LahW2hOmU+iO6nVSq0Mzih1B7ik6M3OSUWwNqDdojUCObAoDts5jqX0Y20tQbq38GUX37EqkzMyUYtTRvDtWVrEjuFswMICzloOpqwdsC9SWordApi3JvcZJzHN7jZnZzliTCKoWmJHKR56cPbal0qNQtyCP1FsrdKTYnkpHgFtwe6Ay03+eQm+i3BmQGQCiaUFL1a0yGSW2AC/HadXtgW9dZw1qBH3ktS0la936LUBb0Eb2I7IZFsQjXjsLvBaFh9azyj0Kt1XesiEZBWWUPAN/dGyrw7kBxt2xsTO6zbZmUFpQWVbEUnNPwVsKHcFula1D0GtJWtCbIT4H3BEMnnpHkLHTg1qVmc7QOudoQNkSgFYnsBqvNYsQQYb9nipH9oPpOB7ErGr3KHQkBg+L70y4WVW3lCyyJ5FX9wahmQGnB3QLZk+VIyviQc5YlMh/Z8GN8kcQR+eziWrfa8zkgDJSJbaxM8B44DIwomxW4Zl6S4O17jqRSrf2t+yIVrys/2YsB3NXKOcfDSitfMtVuxduVqF140UgzLInlp2JAI/KtGxKfZ29iq1jlVVwxkawCh2B7Sl5a3urQ/ZcOyUcPco9A26vjmhwyahq5KlLHezMiHWuUUelgk9kYhXcypdR9Jaae2Ayg92savcouhvG2XC3wGfUL6veluK2trFAR2MARq2zKt4aPHrqxvhda2DJAMvcDSx4o+toDQp795mAbwl3pN4txYwGmDMAH1XsGXDXjcbMQkSWggW2lc9SVyv/pqp9r/E6BpTlpFuNl9mXmT3xoM0qeMbeMJ2QiQnhQh7KEqmfBodV8Mh+WPs9lb9o1b5WuFcDPqLYWbX2gGdvzz1QewCvBttSfO/OpOPSiocrGlsodwSPpYItde+1KJHas4o9C2gW9Jaqj8LeUunMANICOQKU7dD0HXAV3B4Y9Ym15rpXAN4DMzMrkrFgLMCMomU9eFaZmfpbahzN9DDXGKl9E/QRuCOAI0WLvPYswPV5Zqcb2TuNFegoBqVMpGpWvsiXR4NLxp5ECuyddwbsCGA2NnfivxLuCP4MNJGCMlN3TB6vI+jAsR2TvoUaGSN4PeVjrMkMsD0oZ4Idgb+ZclvKy6ibp3a9gHt2JAKZsU319bAqzQIfKVbLNsyAN4KU7XyZ69CxicouhbtHnbcGPLpjsKo8G+YI+gg2xrp489FsR2nZKBZ2745jXf/Fw93bARgFHwGVgZg9h5kK3jNrEIE/MjiMwGftSQ+8m8PdC++Ij2UsQ8vGRBYn6jSeys5Sc6ZRI6A1dJGy9uy/WLDvNeDAJ5RZtWIanlFTz8tHZaP9rU7KlI1sxej+CD7vdh+Vi/Z7AK8Eu3VMOo6z4GbUeyQPO5fM2AgGVPZ4zPiBbgzJGCl2Zn8vtMwdYQRsBtzoOqmYXiLcXifIADcCMGN5ZkPd40dLmR4YPXh66vLOwwOQAZfJEwI+E+4RZWZhGQXcOkdG7bMWLAz8QAZGkTMWxVLS7KCWhZHJx+ShwrcF3GwnaOU7J+QlkNGYIdpPNUiVKWrkDICsUkeWIduxvE7WikV03XQcZ8M9A1x98lllzdoaxsJ4AZ0N9MitfFSBM51lhRWJOhYN9UNqNGm2pPe2nYFjNeTZTpEO9oICGUX2gIyUsucYPYp9FXBn1HtW3qiT9Khzxvos4PZOlb0QbgV1Ftbo+tIxXmFLWI/aq/atDrEC8p7ryZTpaVS2TI9H7rEnFnjsOWY7AQ35SrhnqXKP3+2BPHu+I52TbaAMIJEPjuqaBXUW1ui82Fjdybca7h5gIjD1RYzah9Hy3cGfVHAUytHyvf462wnS4bpEuHs6RFSG7TCz86UbpFGAVbgZ+dg6Lhbse0AsmC3psRHnLMMCnPHNMyHO1JWFMMof7R/11pF1ylx7mPeccEfqOhNwBsws5Bk7FAY+maEHOhaklXXP6gzJcP1/9nPD3Qv4SDm27CjsXQ2wqBADLJPHO73esr3lusK0BdwsbCuUPHPsa4E9A0wmr47/VmW7wN5KueuTHQVoy/Kjx840Wi9YveXqcxutY7R8Jk4Py7uVcs8EPKPGTKDOCS1zPpk8s0CaUc+MOjLXfifvJcBdTmoWVLPq0cFaVW+2AVdBM6veWfVk43LRcM9W89mKPhzsC6xgJogz65oSqktSbuuCZqvl7PqmNMIZK5kN4Oz6pobi0uFeoeaXajemNqxUtgq8VfXOvv5N5rlnXMS5FPhcx+mNyblAO9dxeuNglrsm5W5d+KVDOLXRzlDZVcJ855Z8xmdLztAmDzvEATwX8V2AbA7Ydgy317S3Cv1uIXYb+gbhjvTsWuG/OXjDhjzgjkJ07L/WCOxlQHmt8T/Oe2EEDrgXBveoetsIHHBvG//j6AsjcMC9MLhH1dtG4IB72/gfR18YgQPuhcE9qt42Agfc28b/OPrCCPwfQYtbUK+4RJcAAAAASUVORK5CYII="
          />
        </g>
      </svg>

      <h1
        data-aos="fade-right"
        data-aos-duration="1000"
        
        data-aos-once="false"
      >
        {{ data.title }}
      </h1>
      <h3
        data-aos="fade-right"
        data-aos-duration="1500"
        
        data-aos-once="false"
      >
        {{ data.summary }}
      </h3>
      <div
        data-aos="fade-right"
        data-aos-duration="1500"
        
        data-aos-once="false"
        class="lineBreak"
      >
        <span class="showInMobile"></span>
        <span class="large"></span>
        <span></span>
      </div>
      <button
        data-aos="fade-right"
        data-aos-duration="2000"
        
        data-aos-once="false"
        id="seeTour"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink"
          width="48"
          height="48"
          viewBox="0 0 58.1 58.1"
        >
          <g
            id="tour_button"
            data-name="tour button"
            transform="translate(-468.32 -1711.9)"
          >
            <circle
              id="Ellipse_6"
              data-name="Ellipse 6"
              cx="29.05"
              cy="29.05"
              r="29.05"
              transform="translate(468.32 1711.9)"
              fill="#fff"
            />
            <image
              id="Layer_2613_copy_2"
              data-name="Layer 2613 copy 2"
              width="16"
              height="16"
              transform="translate(489 1733)"
              xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAARhJREFUOE+Vk8FKAlEUhmfc2KqVC8EgcO1ztAkSAjcuAxcGLnQVQmQKykBotWghbnyELN247z1aF0FqtDHt++FeGEZmnLnwcS7MOd85c++M+3yY+XUc5x0u4A0SLRfB1lT8ESdQAu1jLStQYQHypnhGLMNqn8UKGiQO4ATGkDUiic+jJFZwS1LLl6iiBzgyoleizugrKAsT2LxTNiPfRFP2Rb9kn8DmnrF5ghxs4AUq8BFXYEU6oyEcwxrmSQUS1eAeUvCZRNCnoAoH8A098OIIuiTqmtPwA014tO8UJVDHS1O4JN5B2xYGBTe+h+pYN6PudAwTaCyNeGXiwnTsBAvCBLpbnao6XoM+61hLZ6A/Tz+NBxo/0foHIeNW4gFKldMAAAAASUVORK5CYII="
            />
          </g>
        </svg>
        <span
          data-aos="fade-right"
          data-aos-duration="2000"
          
          data-aos-once="false"
        >
          مشاهده آنلاین تور مجازی
        </span>
      </button>
    </div>
    <img
      data-aos="fade-left"
      data-aos-duration="1500"
      
      data-aos-once="false"
      class="width40"
      :src="data.image"
      alt=""
    />
  </div>
</template>
<script>
export default {
  props: {
    data: Object
  }
};
</script>
